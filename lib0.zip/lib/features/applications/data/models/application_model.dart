// lib/features/applications/data/models/application_model.dart
import 'package:cloud_firestore/cloud_firestore.dart';
import '../../domain/entities/application_entity.dart';

class ApplicationModel extends ApplicationEntity {
  const ApplicationModel({
    required super.id,
    required super.listingId,
    required super.applicantId,
    required super.requestedMoveIn,
    required super.message,
    required super.status,
    required super.submittedAt,
  });

  factory ApplicationModel.fromMap({
    required String id,
    required Map<String, dynamic> map,
  }) {
    return ApplicationModel(
      id: id,
      listingId: map['listingId'] as String? ?? '',
      applicantId: map['applicantId'] as String? ?? '',
      requestedMoveIn: (map['requestedMoveIn'] as Timestamp?)?.toDate() ??
          DateTime.now(),
      message: map['message'] as String? ?? '',
      status: _parseStatus(map['status'] as String?),
      submittedAt: (map['submittedAt'] as Timestamp?)?.toDate() ??
          DateTime.now(),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'listingId': listingId,
      'applicantId': applicantId,
      'requestedMoveIn': requestedMoveIn,
      'message': message,
      'status': status.name,
      'submittedAt': submittedAt,
    };
  }

  static ApplicationStatus _parseStatus(String? value) {
    for (final s in ApplicationStatus.values) {
      if (s.name == value) return s;
    }
    return ApplicationStatus.pending;
  }
}
