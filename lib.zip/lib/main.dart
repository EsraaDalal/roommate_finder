import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:rommate_finder/core/config/di.dart';
import 'package:rommate_finder/core/config/supabase_config.dart';
import 'package:rommate_finder/features/auth/presentation/bloc/auth/auth_bloc.dart';
import 'package:rommate_finder/features/auth/presentation/bloc/auth_session/auth_session_bloc.dart';
import 'package:rommate_finder/firebase_options.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'core/resources/app_theme.dart';
import 'core/resources/theme_controller.dart';
import 'features/auth/presentation/bloc/auth_session/auth_session_event.dart';
import 'features/auth/presentation/pages/splash_page.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  if (SupabaseConfig.isConfigured) {
    await Supabase.initialize(
      url: SupabaseConfig.url,
      publishableKey: SupabaseConfig.publishableKey,
      accessToken: () async {
        return FirebaseAuth.instance.currentUser?.getIdToken();
      },
    );
  }
  await setupDependencies();
  runApp(const RoommateFinderApp());
}

class RoommateFinderApp extends StatelessWidget {
  const RoommateFinderApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: ThemeController.instance,
      builder: (BuildContext context, _) {
        return MultiBlocProvider(
          providers: [
            BlocProvider<AuthBloc>(create: (_) => getIt<AuthBloc>()),
            BlocProvider<AuthSessionBloc>(
              create: (_) =>
                  getIt<AuthSessionBloc>()..add(const AuthSessionStarted()),
            ),
          ],
          child: MaterialApp(
            title: 'Roommate Finder',
            debugShowCheckedModeBanner: false,
            theme: AppTheme.light,
            darkTheme: AppTheme.dark,
            themeMode: ThemeController.instance.mode,
            home: const SplashPage(),
          ),
        );
      },
    );
  }
}
