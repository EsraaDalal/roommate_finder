import 'package:get_it/get_it.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:dio/dio.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../features/chat/data/datasource/chat_remote_data_source.dart';
import '../../features/chat/data/repositories/chat_repository_impl.dart';
import '../../features/chat/domain/repositories/chat_repository.dart';
import '../../features/chat/domain/usecases/get_conversations_usecase.dart';
import '../../features/chat/domain/usecases/get_messages_usecase.dart';
import '../../features/chat/domain/usecases/get_or_create_conversation_usecase.dart';
import '../../features/chat/domain/usecases/get_user_by_uid_usecase.dart';
import '../../features/chat/domain/usecases/send_message_usecase.dart';
import '../../features/chat/presentation/bloc/chat_bloc.dart';
import '../../features/profile/data/datasources/profile_remote_data_source.dart';
import '../../features/profile/data/repositories/profile_repository_impl.dart';
import '../../features/profile/domain/repositories/profile_repository.dart';
import '../../features/profile/domain/usecases/get_profile_usecase.dart';
import '../../features/profile/domain/usecases/update_profile_usecase.dart';
import '../../features/profile/presentation/bloc/profile_bloc.dart';
import 'supabase_config.dart';

import '../../features/auth/data/datasources/auth_data_source.dart';
import '../../features/auth/data/datasources/onboarding_local_data_source.dart';

import '../../features/auth/data/repositories/auth_repository_impl.dart';
import '../../features/auth/data/repositories/onboarding_repository_impl.dart';

import '../../features/auth/domain/repositories/auth_repository.dart';
import '../../features/auth/domain/repositories/onboarding_repository.dart';

import '../../features/auth/domain/usecases/get_current_user_use_case.dart';
import '../../features/auth/domain/usecases/auth_state_changes_use_case.dart';
import '../../features/auth/domain/usecases/is_onboarding_completed_use_case.dart';
import '../../features/auth/domain/usecases/complete_onboarding_use_case.dart';

import '../../features/auth/domain/usecases/login_usecase.dart';
import '../../features/auth/domain/usecases/logout_usecase.dart';
import '../../features/auth/domain/usecases/register_usecase.dart';
import '../../features/auth/presentation/bloc/auth/auth_bloc.dart';
import '../../features/auth/presentation/bloc/auth_session/auth_session_bloc.dart';

import '../../features/hosting/data/datasources/listing_image_upload_data_source.dart';
import '../../features/hosting/data/datasources/listing_remote_data_source.dart';
import '../../features/hosting/data/repositories/listing_image_repository_impl.dart';
import '../../features/hosting/data/repositories/listing_repository_impl.dart';

import '../../features/hosting/domain/repositories/listing_image_repository.dart';
import '../../features/hosting/domain/repositories/listing_repository.dart';
import '../../features/hosting/domain/usecases/create_listing_usecase.dart';
import '../../features/hosting/domain/usecases/get_my_listings_usecase.dart';
import '../../features/hosting/domain/usecases/update_listing_usecase.dart';
import '../../features/hosting/domain/usecases/delete_listing_usecase.dart';
import '../../features/hosting/domain/usecases/upload_listing_images_usecase.dart';
import '../../features/hosting/presentation/bloc/hosting_bloc.dart';

import '../../features/home/data/datasources/home_remote_data_source.dart';
import '../../features/home/data/repositories/home_repository_impl.dart';
import '../../features/home/domain/repositories/home_repository.dart';
import '../../features/home/domain/usecases/get_home_listings_usecase.dart';
import '../../features/home/presentation/bloc/home_bloc.dart';

final GetIt getIt = GetIt.instance;

Future<void> setupDependencies() async {
  // External dependencies
  getIt.registerSingleton<SharedPreferences>(
    await SharedPreferences.getInstance(),
  );

  getIt.registerLazySingleton<FirebaseAuth>(() => FirebaseAuth.instance);

  getIt.registerLazySingleton<FirebaseFirestore>(
    () => FirebaseFirestore.instance,
  );

  if (SupabaseConfig.isConfigured) {
    getIt.registerLazySingleton<SupabaseClient>(() => Supabase.instance.client);
  }

  // HTTP client used to reach the Supabase Edge Functions.
  getIt.registerLazySingleton<Dio>(
    () => Dio(
      BaseOptions(
        connectTimeout: const Duration(seconds: 30),
        // Uploads of up to six images can take a while on slow connections.
        sendTimeout: const Duration(minutes: 5),
        receiveTimeout: const Duration(minutes: 2),
      ),
    ),
  );

  // Data sources
  getIt.registerLazySingleton<AuthDataSource>(
    () => AuthDataSourceImpl(
      firebaseAuth: getIt<FirebaseAuth>(),
      firestore: getIt<FirebaseFirestore>(),
    ),
  );

  getIt.registerLazySingleton<OnboardingLocalDataSource>(
    () => OnboardingLocalDataSourceImpl(
      sharedPreferences: getIt<SharedPreferences>(),
    ),
  );

  // Repositories
  getIt.registerLazySingleton<AuthRepository>(
    () => AuthRepositoryImpl(dataSource: getIt<AuthDataSource>()),
  );

  getIt.registerLazySingleton<OnboardingRepository>(
    () => OnboardingRepositoryImpl(
      localDataSource: getIt<OnboardingLocalDataSource>(),
    ),
  );

  // Auth use cases
  getIt.registerLazySingleton<RegisterUseCase>(
    () => RegisterUseCase(repository: getIt<AuthRepository>()),
  );

  getIt.registerLazySingleton<LoginUseCase>(
    () => LoginUseCase(repository: getIt<AuthRepository>()),
  );

  getIt.registerLazySingleton<LogoutUseCase>(
    () => LogoutUseCase(repository: getIt<AuthRepository>()),
  );

  getIt.registerLazySingleton<GetCurrentUserUseCase>(
    () => GetCurrentUserUseCase(repository: getIt<AuthRepository>()),
  );

  getIt.registerLazySingleton<AuthStateChangesUseCase>(
    () => AuthStateChangesUseCase(repository: getIt<AuthRepository>()),
  );

  // Onboarding use cases
  getIt.registerLazySingleton<IsOnboardingCompletedUseCase>(
    () =>
        IsOnboardingCompletedUseCase(repository: getIt<OnboardingRepository>()),
  );

  getIt.registerLazySingleton<CompleteOnboardingUseCase>(
    () => CompleteOnboardingUseCase(repository: getIt<OnboardingRepository>()),
  );

  // Blocs
  getIt.registerFactory<AuthBloc>(
    () => AuthBloc(
      registerUseCase: getIt<RegisterUseCase>(),
      loginUseCase: getIt<LoginUseCase>(),
      logoutUseCase: getIt<LogoutUseCase>(),
    ),
  );

  getIt.registerFactory<AuthSessionBloc>(
    () => AuthSessionBloc(
      authStateChangesUseCase: getIt<AuthStateChangesUseCase>(),
    ),
  );

  // Hosting data source
  getIt.registerLazySingleton<ListingRemoteDataSource>(
    () => ListingRemoteDataSourceImpl(
      firestore: getIt<FirebaseFirestore>(),
      firebaseAuth: getIt<FirebaseAuth>(),
    ),
  );

  // Listing image upload data source
  getIt.registerLazySingleton<ListingImageUploadDataSource>(
    () => ListingImageUploadDataSourceImpl(
      dio: getIt<Dio>(),
      firebaseAuth: getIt<FirebaseAuth>(),
    ),
  );

  // Hosting repository
  getIt.registerLazySingleton<ListingRepository>(
    () => ListingRepositoryImpl(
      remoteDataSource: getIt<ListingRemoteDataSource>(),
    ),
  );

  // Hosting image repository
  getIt.registerLazySingleton<ListingImageRepository>(
    () => ListingImageRepositoryImpl(
      uploadDataSource: getIt<ListingImageUploadDataSource>(),
    ),
  );

  // Hosting use cases
  getIt.registerLazySingleton<CreateListingUseCase>(
    () => CreateListingUseCase(repository: getIt<ListingRepository>()),
  );

  getIt.registerLazySingleton<GetMyListingsUseCase>(
    () => GetMyListingsUseCase(repository: getIt<ListingRepository>()),
  );

  getIt.registerLazySingleton<UpdateListingUseCase>(
    () => UpdateListingUseCase(repository: getIt<ListingRepository>()),
  );

  getIt.registerLazySingleton<DeleteListingUseCase>(
    () => DeleteListingUseCase(repository: getIt<ListingRepository>()),
  );

  // Hosting image use case
  getIt.registerLazySingleton<UploadListingImagesUseCase>(
    () =>
        UploadListingImagesUseCase(repository: getIt<ListingImageRepository>()),
  );

  getIt.registerFactory<HostingBloc>(
    () => HostingBloc(
      createListingUseCase: getIt<CreateListingUseCase>(),
      getMyListingsUseCase: getIt<GetMyListingsUseCase>(),
      updateListingUseCase: getIt<UpdateListingUseCase>(),
      deleteListingUseCase: getIt<DeleteListingUseCase>(),
      uploadListingImagesUseCase: getIt<UploadListingImagesUseCase>(),
    ),
  );

  // Home data source
  getIt.registerLazySingleton<HomeRemoteDataSource>(
    () => HomeRemoteDataSourceImpl(firestore: getIt<FirebaseFirestore>()),
  );

  // Home repository
  getIt.registerLazySingleton<HomeRepository>(
    () => HomeRepositoryImpl(remoteDataSource: getIt<HomeRemoteDataSource>()),
  );

  // Home use case
  getIt.registerLazySingleton<GetHomeListingsUseCase>(
    () => GetHomeListingsUseCase(getIt<HomeRepository>()),
  );

  // Home bloc
  getIt.registerFactory<HomeBloc>(
    () => HomeBloc(getHomeListingsUseCase: getIt<GetHomeListingsUseCase>()),
  );

  // Profile data source
  getIt.registerLazySingleton<ProfileRemoteDataSource>(
    () => ProfileRemoteDataSourceImpl(
      firestore: getIt<FirebaseFirestore>(),
      firebaseAuth: getIt<FirebaseAuth>(),
    ),
  );

  // Profile repository
  getIt.registerLazySingleton<ProfileRepository>(
    () => ProfileRepositoryImpl(
      remoteDataSource: getIt<ProfileRemoteDataSource>(),
    ),
  );

  // Profile use cases
  getIt.registerLazySingleton<GetProfileUseCase>(
    () => GetProfileUseCase(repository: getIt<ProfileRepository>()),
  );

  getIt.registerLazySingleton<UpdateProfileUseCase>(
    () => UpdateProfileUseCase(repository: getIt<ProfileRepository>()),
  );

  getIt.registerFactory(
    () => ProfileBloc(
      getProfileUseCase: getIt<GetProfileUseCase>(),
      updateProfileUseCase: getIt<UpdateProfileUseCase>(),
    ),
  );

  
getIt.registerLazySingleton<ChatRemoteDataSource>(
  () => ChatRemoteDataSourceImpl(
    firestore: getIt<FirebaseFirestore>(),
    firebaseAuth: getIt<FirebaseAuth>(),
  ),
);

getIt.registerLazySingleton<ChatRepository>(
  () => ChatRepositoryImpl(
    remoteDataSource: getIt<ChatRemoteDataSource>(),
  ),
);


getIt.registerLazySingleton(
  () => GetConversationsUseCase(
    repository: getIt(),
  ),
);

getIt.registerLazySingleton(
  () => GetMessagesUseCase(
    repository: getIt(),
  ),
);

getIt.registerLazySingleton(
  () => GetOrCreateConversationUseCase(
    repository: getIt(),
  ),
);
getIt.registerLazySingleton(
  () => GetUserByUidUseCase(
    repository: getIt(),
  ),
);

getIt.registerLazySingleton(
  () => SendMessageUseCase(
    repository: getIt(),
  ),
);

getIt.registerFactory<ChatBloc>(
  () => ChatBloc(
    getConversationsUseCase: getIt(),
    getMessagesUseCase: getIt(),
    getOrCreateConversationUseCase: getIt(),
    sendMessageUseCase: getIt(),
    getUserByUidUseCase: getIt(),
  ),
);
}
