import 'package:flutter/foundation.dart';

import '../../applications/data/mock_users.dart';

/// In-memory current-user state for the current session.
///
/// Follows the same lightweight pattern as the other session stores: a
/// [ChangeNotifier] singleton with no package and no persistence. Profile
/// edits update this store so every screen that reads the current user
/// reflects the change immediately.
class CurrentUserStore extends ChangeNotifier {
  CurrentUserStore();

  static final CurrentUserStore instance = CurrentUserStore();

  MockUser _user = const MockUser(
    id: CurrentUser.id,
    name: 'Alex Morgan',
    initials: 'AM',
    bio: 'Graduate student, tidy roommate, and weekend trail explorer.',
    email: 'alex.morgan@example.com',
    city: 'Austin, Texas',
  );

  Uint8List? _photo;

  MockUser get user => _user;
  Uint8List? get photo => _photo;

  void updateUser(MockUser user) {
    _user = user;
    notifyListeners();
  }

  void updatePhoto(Uint8List? photo) {
    _photo = photo;
    notifyListeners();
  }
}
