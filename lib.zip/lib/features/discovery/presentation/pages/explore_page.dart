import 'package:flutter/material.dart';

import '../../../../core/resources/app_spacing.dart';
import '../../../../core/widgets/pill_search_field.dart';
import '../../../../core/widgets/section_label.dart';
import '../../data/favorites_store.dart';
import '../../data/listing.dart';
import '../../data/listings_store.dart';
import '../widgets/filter_bottom_sheet.dart';
import '../widgets/listing_card.dart';
import '../widgets/listing_card_widgets.dart';
import 'listing_details_page.dart';

/// Explore screen.
///
/// Mirrors `ai/design/explore_page.png`: location eyebrow, "Find your space"
/// heading, search field with a filter button, category chips, a result count
/// with "Best match", and the vertical listing list.
class ExplorePage extends StatefulWidget {
  const ExplorePage({super.key});

  @override
  State<ExplorePage> createState() => _ExplorePageState();
}

class _ExplorePageState extends State<ExplorePage> {
  final TextEditingController _searchController = TextEditingController();

  ListingFilters _filters = const ListingFilters();
  ListingCategory? _category;

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  void _onSearchChanged(String value) {
    setState(() => _filters = _filters.copyWith(query: value));
  }

  void _clearSearch() {
    _searchController.clear();
    setState(() => _filters = _filters.copyWith(query: ''));
  }

  Future<void> _openFilters() async {
    final ListingFilters? result =
        await showListingFilterSheet(context, _filters);
    if (result != null && mounted) {
      setState(() => _filters = result);
    }
  }

  List<Listing> get _visibleListings {
    final List<Listing> byFilters =
        _filters.apply(ListingsStore.instance.all);
    if (_category == null) {
      return byFilters;
    }
    return byFilters
        .where((Listing listing) => listing.category == _category)
        .toList(growable: false);
  }

  void _openDetails(Listing listing) {
    // Navigator.of(context).push(
    //   MaterialPageRoute<void>(
    //     builder: (_) => ListingDetailsPage(listing: listing),
    //   ),
    // );
  }

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final List<Listing> listings = _visibleListings;

    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(
                AppSpacing.pageHorizontal,
                AppSpacing.sm,
                AppSpacing.pageHorizontal,
                0,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SectionLabel('Austin, Texas'),
                  const SizedBox(height: AppSpacing.xs),
                  Text('Find your space', style: theme.textTheme.displayMedium),
                  const SizedBox(height: AppSpacing.md),
                  PillSearchField(
                    controller: _searchController,
                    hint: 'City or area',
                    onChanged: _onSearchChanged,
                    onClear: _clearSearch,
                    onFilterTap: _openFilters,
                  ),
                  const SizedBox(height: AppSpacing.md),
                  SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      children: [
                        _CategoryChip(
                          label: 'All homes',
                          selected: _category == null,
                          onTap: () => setState(() => _category = null),
                        ),
                        const SizedBox(width: AppSpacing.xs),
                        _CategoryChip(
                          label: 'Apartment',
                          selected: _category == ListingCategory.apartment,
                          onTap: () => setState(
                            () => _category = ListingCategory.apartment,
                          ),
                        ),
                        const SizedBox(width: AppSpacing.xs),
                        _CategoryChip(
                          label: 'University',
                          selected: _category == ListingCategory.university,
                          onTap: () => setState(
                            () => _category = ListingCategory.university,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: AppSpacing.md),
                  Row(
                    children: [
                      Text(
                        '${listings.length} places',
                        style: theme.textTheme.titleMedium,
                      ),
                      const Spacer(),
                      Text('Best match', style: theme.textTheme.bodySmall),
                    ],
                  ),
                  const SizedBox(height: AppSpacing.xs),
                ],
              ),
            ),
            Expanded(
              child: listings.isEmpty
                  ? EmptyResults(
                      title: 'No places found',
                      message:
                          'Try a different search or clear your filters to see '
                          'more listings.',
                      actionLabel: 'Clear filters',
                      onAction: () {
                        _searchController.clear();
                        setState(() {
                          _category = null;
                          _filters = const ListingFilters();
                        });
                      },
                    )
                  : ListenableBuilder(
                      listenable: Listenable.merge([
                        FavoritesStore.instance,
                        ListingsStore.instance,
                      ]),
                      builder: (BuildContext context, Widget? child) {
                        return ListView.separated(
                          padding: const EdgeInsets.fromLTRB(
                            AppSpacing.pageHorizontal,
                            0,
                            AppSpacing.pageHorizontal,
                            AppSpacing.lg,
                          ),
                          itemCount: listings.length,
                          separatorBuilder: (_, _) =>
                              const SizedBox(height: AppSpacing.sm),
                          itemBuilder: (BuildContext context, int index) {
                            final Listing listing = listings[index];
                            return ListingListCard(
                              listing: listing,
                              isFavorite:
                                  FavoritesStore.instance.contains(listing.id),
                              onFavoriteToggle: () =>
                                  FavoritesStore.instance.toggle(listing.id),
                              onTap: () => _openDetails(listing),
                            );
                          },
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}

class _CategoryChip extends StatelessWidget {
  const _CategoryChip({
    required this.label,
    required this.selected,
    required this.onTap,
  });

  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);

    return Material(
      color: selected
          ? theme.colorScheme.primaryContainer
          : theme.colorScheme.surface,
      borderRadius: BorderRadius.circular(AppRadius.pill),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(AppRadius.pill),
        child: Padding(
          padding: const EdgeInsets.symmetric(
            horizontal: AppSpacing.md,
            vertical: AppSpacing.xs,
          ),
          child: Text(
            label,
            style: theme.textTheme.bodyMedium?.copyWith(
              fontWeight: FontWeight.w600,
              color: selected
                  ? theme.colorScheme.secondary
                  : theme.textTheme.bodyMedium?.color,
            ),
          ),
        ),
      ),
    );
  }
}