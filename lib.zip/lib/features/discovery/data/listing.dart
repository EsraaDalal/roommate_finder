import 'package:flutter/foundation.dart';

/// Housing categories shown as chips on the Explore screen.
enum ListingCategory { apartment, university }

/// Room type used by the filter sheet.
enum RoomType {
  apartment('Apartment'),
  house('House'),
  studio('Studio'),
  universityRoom('University room');

  const RoomType(this.label);

  final String label;
}

/// A person already living in the listing.
class Roommate {
  const Roommate({
    required this.initials,
    required this.name,
    required this.tagline,
  });

  final String initials;
  final String name;
  final String tagline;
}

/// The listing owner.
class ListingHost {
  const ListingHost({
    required this.initials,
    required this.name,
    required this.responseTime,
  });

  final String initials;
  final String name;
  final String responseTime;
}

/// A single housing listing.
///
/// Mock data for the UI stage; no serialization or persistence yet.
@immutable
class Listing {
  const Listing({
    required this.id,
    required this.title,
    required this.description,
    required this.priceMonthly,
    required this.area,
    required this.roomType,
    required this.category,
    required this.furnished,
    required this.peopleCount,
    required this.spacesRemaining,
    required this.rules,
    required this.roommates,
    required this.host,
   required this.photoCount,
    this.isPublished = true,
    this.ownerId = 'user-sarah',
  });

  final String id;
  final String title;
  final String description;
  final int priceMonthly;

  /// Area label such as "Downtown, Austin".
  final String area;
  final RoomType roomType;
  final ListingCategory category;
  final bool furnished;

  /// Number of people currently living in the home.
  final int peopleCount;
  final int spacesRemaining;

  final List<String> rules;
  final List<Roommate> roommates;
  final ListingHost host;
  final int photoCount;

  /// Draft listings are shown in My Listings but are not part of the spec's
  /// published housing inventory.
  final bool isPublished;

  /// Mock user id of the owner. Only the current user's listings appear in My
  /// Listings, and only they may review applications received for a listing.
  final String ownerId;

  String get furnishedLabel => furnished ? 'Furnished' : 'Unfurnished';


}

/// Active search and filter selection applied to the mock listings.
@immutable
class ListingFilters {
  const ListingFilters({
    this.query = '',
    this.areaQuery = '',
    this.maxPrice = kDefaultMaxPrice,
    this.roomType,
    this.peopleCount,
  });

  static const int kDefaultMaxPrice = 1000;
  static const int kMinPrice = 200;
  static const int kMaxPrice = 1500;

  /// Text typed into the Home / Explore search field.
  final String query;

  /// Text typed into the filter sheet's "City / Area" field.
  final String areaQuery;
  final int maxPrice;
  final RoomType? roomType;
  final int? peopleCount;

  bool get hasActiveFilters =>
      areaQuery.isNotEmpty ||
      maxPrice != kDefaultMaxPrice ||
      roomType != null ||
      peopleCount != null;

  ListingFilters copyWith({
    String? query,
    String? areaQuery,
    int? maxPrice,
    RoomType? roomType,
    int? peopleCount,
    bool clearRoomType = false,
    bool clearPeopleCount = false,
  }) {
    return ListingFilters(
      query: query ?? this.query,
      areaQuery: areaQuery ?? this.areaQuery,
      maxPrice: maxPrice ?? this.maxPrice,
      roomType: clearRoomType ? null : (roomType ?? this.roomType),
      peopleCount:
          clearPeopleCount ? null : (peopleCount ?? this.peopleCount),
    );
  }

  /// Applies this selection to [listings] in memory.
  List<Listing> apply(List<Listing> listings) {
  
    final String area = areaQuery.trim().toLowerCase();

    return listings.where((Listing listing) {
      
      if (area.isNotEmpty && !listing.area.toLowerCase().contains(area)) {
        return false;
      }
      if (listing.priceMonthly > maxPrice) {
        return false;
      }
      if (roomType != null && listing.roomType != roomType) {
        return false;
      }
      if (peopleCount != null && listing.peopleCount != peopleCount) {
        return false;
      }
      return true;
    }).toList(growable: false);
  }
}