import 'listing.dart';

/// Mock listings for the UI stage.
///
/// Titles, prices, areas, and people mirror the Figma frames so the rendered
/// screens match the designs.
const List<Listing> kMockListings = [
  Listing(
    id: 'bright-room-near-campus',
    title: 'Bright room near campus',
    description:
        'A calm, sun-filled room in a welcoming shared apartment. Walk to '
        'cafes, transit, and campus in minutes.',
    priceMonthly: 680,
    area: 'Downtown, Austin',
    roomType: RoomType.apartment,
    category: ListingCategory.apartment,
    furnished: true,
    peopleCount: 3,
    spacesRemaining: 1,
    rules: [
      'No smoking',
      'Quiet hours after 10 PM',
      'Keep shared spaces tidy',
      'One month notice when moving out',
    ],
    roommates: [
      Roommate(
        initials: 'JD',
        name: 'Jamie & Drew',
        tagline: 'Designer and graduate student',
      ),
    ],
    host: ListingHost(
      initials: 'SM',
      name: 'Sarah Miller',
      responseTime: 'Usually responds within an hour',
    ),
    photoCount: 4,
    ownerId: 'user-alex',
  ),
  Listing(
    id: 'cozy-furnished-studio',
    title: 'Cozy furnished studio',
    description:
        'A bright corner studio with everything in place. Shared garden and '
        'bike storage in the building.',
    priceMonthly: 920,
    area: 'North Loop, Austin',
    roomType: RoomType.studio,
    category: ListingCategory.apartment,
    furnished: true,
    peopleCount: 1,
    spacesRemaining: 1,
    rules: [
      'No pets',
      'No smoking',
      'Quiet hours after 11 PM',
    ],
    roommates: <Roommate>[],
    host: ListingHost(
      initials: 'SM',
      name: 'Sarah Miller',
      responseTime: 'Usually responds within an hour',
    ),
    photoCount: 3,
    isPublished: false,
    ownerId: 'user-alex',
  ),
  Listing(
    id: 'student-room-with-balcony',
    title: 'Student room with balcony',
    description:
        'Sunny room with a small balcony two blocks from the campus bus stop. '
        'Furnished and ready to move in.',
    priceMonthly: 540,
    area: 'West Campus, Austin',
    roomType: RoomType.universityRoom,
    category: ListingCategory.university,
    furnished: true,
    peopleCount: 2,
    spacesRemaining: 1,
    rules: [
      'Students only',
      'No smoking',
      'Keep the balcony clear',
    ],
    roommates: [
      Roommate(
        initials: 'AL',
        name: 'Ava Lin',
        tagline: 'Nursing student and part-time barista',
      ),
    ],
    host: ListingHost(
      initials: 'RB',
      name: 'Robert Blake',
      responseTime: 'Usually responds within a day',
    ),
    photoCount: 5,
    ownerId: 'user-robert',
  ),
  Listing(
    id: 'quiet-house-room-pond',
    title: 'Quiet house room by the pond',
    description:
        'A calm room in a quiet duplex, shared kitchen and laundry. Ten '
        'minute walk to the park and bus line.',
    priceMonthly: 760,
    area: 'H Mueller, Austin',
    roomType: RoomType.house,
    category: ListingCategory.apartment,
    furnished: false,
    peopleCount: 2,
    spacesRemaining: 2,
    rules: [
      'No smoking',
      'No parties',
      'Share household chores',
    ],
    roommates: [
      Roommate(
        initials: 'NK',
        name: 'Noah Kim',
        tagline: 'Software engineer, early riser',
      ),
    ],
    host: ListingHost(
      initials: 'RB',
      name: 'Robert Blake',
      responseTime: 'Usually responds within a day',
    ),
    photoCount: 4,
    ownerId: 'user-sarah',
  ),
  Listing(
    id: 'modern-loft-downtown',
    title: 'Modern loft downtown',
    description:
        'Top-floor loft with tall windows, in-unit laundry, and a work nook. '
        'Gym and roof deck in the building.',
    priceMonthly: 1240,
    area: 'Rainey Street, Austin',
    roomType: RoomType.apartment,
    category: ListingCategory.apartment,
    furnished: true,
    peopleCount: 3,
    spacesRemaining: 1,
    rules: [
      'No smoking',
      'No pets',
      'Quiet hours after 10 PM',
    ],
    roommates: [
      Roommate(
        initials: 'TW',
        name: 'Tara Wells',
        tagline: 'Product designer and climber',
      ),
    ],
    host: ListingHost(
      initials: 'SM',
      name: 'Sarah Miller',
      responseTime: 'Usually responds within an hour',
    ),
    photoCount: 6,
    ownerId: 'user-sarah',
  ),
];

