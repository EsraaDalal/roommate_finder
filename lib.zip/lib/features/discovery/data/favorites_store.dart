import 'package:flutter/foundation.dart';

/// In-memory favorite state shared across Home, Explore, Favorites, and Listing
/// Details for the current session.
///
/// This is deliberately a plain [ChangeNotifier] singleton rather than a state
/// management package: no dependency is added and nothing is persisted.
class FavoritesStore extends ChangeNotifier {
  FavoritesStore();

  static final FavoritesStore instance = FavoritesStore();

  final Set<String> _ids = <String>{};

  bool contains(String listingId) => _ids.contains(listingId);

  /// Drops [listingId] without toggling. Used when its listing is deleted.
  void remove(String listingId) {
    if (_ids.remove(listingId)) {
      notifyListeners();
    }
  }

  /// Adds or removes [listingId]; returns true when it is now favorited.
  bool toggle(String listingId) {
    final bool added = !_ids.remove(listingId);
    if (added) {
      _ids.add(listingId);
    }
    notifyListeners();
    return added;
  }
}