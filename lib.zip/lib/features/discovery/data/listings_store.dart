import 'package:flutter/foundation.dart';

import 'favorites_store.dart';
import 'listing.dart';
import 'mock_listings.dart';

/// In-memory listing collection for the current session.
///
/// Seeds from [kMockListings] and is the single source of truth read by Home,
/// Explore, Listing Details, and My Listings. Like [FavoritesStore] this is a
/// plain [ChangeNotifier] singleton: no package is added and nothing is
/// persisted.
class ListingsStore extends ChangeNotifier {
  /// [favorites] is injectable so tests can supply an isolated store.
  ListingsStore({FavoritesStore? favorites})
      : _favorites = favorites ?? FavoritesStore.instance;

  static final ListingsStore instance = ListingsStore();

  final FavoritesStore _favorites;

  final List<Listing> _listings = List<Listing>.of(kMockListings);

  /// Newest first.
  List<Listing> get all => List<Listing>.unmodifiable(_listings);

  Listing? byId(String id) {
    for (final Listing listing in _listings) {
      if (listing.id == id) {
        return listing;
      }
    }
    return null;
  }

  /// Adds [listing] to the top of the collection.
  void add(Listing listing) {
    _listings.insert(0, listing);
    notifyListeners();
  }

  /// Replaces the listing with the same id, keeping its position.
  void update(Listing listing) {
    final int index =
        _listings.indexWhere((Listing item) => item.id == listing.id);
    if (index == -1) {
      add(listing);
      return;
    }
    _listings[index] = listing;
    notifyListeners();
  }

  /// Removes the listing and drops any favorite pointing at it.
  void remove(String id) {
    _listings.removeWhere((Listing listing) => listing.id == id);
    _favorites.remove(id);
    notifyListeners();
  }

  /// Generates an id for a listing created in this session.
  static String newId() => 'listing-${DateTime.now().microsecondsSinceEpoch}';
}