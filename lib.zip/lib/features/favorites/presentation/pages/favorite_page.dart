import 'package:flutter/material.dart';

import '../../../../core/resources/app_spacing.dart';
import '../../../../core/widgets/app_brand_mark.dart';
import '../../../../core/widgets/section_header.dart';
import '../../../discovery/data/favorites_store.dart';
import '../../../discovery/data/listing.dart';
import '../../../discovery/data/listings_store.dart';
import '../../../discovery/presentation/pages/listing_details_page.dart';
import '../../../discovery/presentation/widgets/listing_card.dart';
import '../../../discovery/presentation/widgets/listing_card_widgets.dart';

/// Favorites screen.
///
/// Mirrors `ai/design/favorite_page.png`: brand mark, "Saved places" heading
/// with subtitle, and the saved listing cards. Favorite state comes from
/// [FavoritesStore], so a change made on Home, Explore, or Listing Details is
/// reflected here immediately.
class FavoritePage extends StatelessWidget {
  const FavoritePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: CustomScrollView(
          slivers: [
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(
                  AppSpacing.pageHorizontal,
                  AppSpacing.md,
                  AppSpacing.pageHorizontal,
                  AppSpacing.md,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const AppBrandMark(),
                    const SizedBox(height: AppSpacing.lg),
                    const SectionHeader(
                      title: 'Saved places',
                      subtitle: 'Homes you would love to come back to.',
                    ),
                  ],
                ),
              ),
            ),
            const SliverToBoxAdapter(child: Divider(height: 1)),
            const _FavoritesList(),
          ],
        ),
      ),
    );
  }
}

class _FavoritesList extends StatelessWidget {
  const _FavoritesList();

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: Listenable.merge([
        FavoritesStore.instance,
        ListingsStore.instance,
      ]),
      builder: (BuildContext context, Widget? child) {
        // Order follows the listing collection so newly saved places appear
        // first and deleted listings disappear.
        final List<Listing> favorites = ListingsStore.instance.all
            .where(
              (Listing listing) =>
                  FavoritesStore.instance.contains(listing.id),
            )
            .toList(growable: false);

        if (favorites.isEmpty) {
          return const SliverFillRemaining(
            hasScrollBody: false,
            child: EmptyResults(
              title: 'No saved places yet',
              message:
                  'Tap the heart on any listing to keep it here for later.',
            ),
          );
        }

        return SliverList.separated(
          itemCount: favorites.length,
          separatorBuilder: (_, _) => const SizedBox(height: AppSpacing.sm),
          itemBuilder: (BuildContext context, int index) {
            final Listing listing = favorites[index];
            return Padding(
              padding: const EdgeInsets.symmetric(
                horizontal: AppSpacing.pageHorizontal,
              ),
              child: ListingListCard(
                listing: listing,
                isFavorite: true,
                onFavoriteToggle: () =>
                    FavoritesStore.instance.toggle(listing.id),
                onTap: (){}
                //  Navigator.of(context).push(
                //   MaterialPageRoute<void>(
                //     builder: (_) => ListingDetailsPage(listing: listing),
                //   ),
                // ),
              ),
            );
          },
        );
      },
    );
  }
}