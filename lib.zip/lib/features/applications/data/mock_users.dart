import 'package:flutter/material.dart';

import '../../profile/data/current_user_store.dart';

/// A mock user profile used as an applicant or listing owner.
@immutable
class MockUser {
  const MockUser({
    required this.id,
    required this.name,
    required this.initials,
    required this.bio,
    this.avatarColor,
    this.email = '',
    this.city = '',
  });

  final String id;
  final String name;
  final String initials;
  final String bio;

  /// Avatar tint. Defaults to the brand avatar green when null.
  final Color? avatarColor;

  /// Contact email. Read-only on the edit-profile form.
  final String email;

  /// City or region label such as "Austin, Texas".
  final String city;
}

/// The signed-in user's stable id.
///
/// The project defines a single user type who both searches for housing and
/// publishes listings, so there is a single current user rather than an
/// account switcher. Mutable profile data lives in [CurrentUserStore].
abstract final class CurrentUser {
  static const String id = 'user-alex';
}

/// Other mock users who apply to the current user's listings, and own the
/// listings the current user applies to.
const List<MockUser> kMockUsers = [
  MockUser(
    id: 'user-maya',
    name: 'Maya Patel',
    initials: 'MP',
    bio: 'Design student, early riser, and tidy by nature.',
  ),
  MockUser(
    id: 'user-daniel',
    name: 'Daniel Lee',
    initials: 'DL',
    bio: 'Software engineer who cooks and cycles on weekends.',
    avatarColor: Color(0xFF8C6A4F),
  ),
  MockUser(
    id: 'user-ava',
    name: 'Ava Lin',
    initials: 'AL',
    bio: 'Nursing student and part-time barista.',
  ),
  MockUser(
    id: 'user-sarah',
    name: 'Sarah Miller',
    initials: 'SM',
    bio: 'Long-time renter who keeps a calm, tidy home.',
  ),
  MockUser(
    id: 'user-robert',
    name: 'Robert Blake',
    initials: 'RB',
    bio: 'Property owner with a handful of quiet rentals.',
  ),
];

/// Resolves a mock user by id. Returns null when the id is unknown.
MockUser? mockUserById(String id) {
  if (id == CurrentUser.id) {
    return CurrentUserStore.instance.user;
  }
  for (final MockUser user in kMockUsers) {
    if (user.id == id) {
      return user;
    }
  }
  return null;
}
