import 'package:flutter/foundation.dart';

/// Lifecycle of a housing application.
enum ApplicationStatus {
  pending('Pending'),
  accepted('Accepted'),
  rejected('Rejected'),
  cancelled('Cancelled');

  const ApplicationStatus(this.label);

  final String label;

  /// Whether the owner may still accept or reject.
  bool get isActionable => this == ApplicationStatus.pending;

  /// Whether the applicant may still withdraw.
  bool get isCancellable => this == ApplicationStatus.pending;
}

/// A housing application submitted by an applicant for a listing.
///
/// Mock data for the UI stage; no serialization or persistence.
@immutable
class HousingApplication {
  const HousingApplication({
    required this.id,
    required this.listingId,
    required this.applicantId,
    required this.requestedMoveIn,
    required this.message,
    required this.status,
    required this.submittedAt,
  });

  final String id;
  final String listingId;
  final String applicantId;

  /// Requested move-in date, only the date portion is used by the UI.
  final DateTime requestedMoveIn;

  /// Optional message to the listing owner.
  final String message;
  final ApplicationStatus status;
  final DateTime submittedAt;

  HousingApplication copyWith({
    DateTime? requestedMoveIn,
    String? message,
    ApplicationStatus? status,
  }) {
    return HousingApplication(
      id: id,
      listingId: listingId,
      applicantId: applicantId,
      requestedMoveIn: requestedMoveIn ?? this.requestedMoveIn,
      message: message ?? this.message,
      status: status ?? this.status,
      submittedAt: submittedAt,
    );
  }
}