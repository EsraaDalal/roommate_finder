import 'housing_application.dart';

/// Seed applications.
///
/// Consistency rules encoded here:
/// * Outgoing applications reference listings owned by other users.
/// * Incoming applications reference published listings owned by the current
///   user, so they surface in Received Applications.
/// * The draft listing ("Cozy furnished studio") receives none, since drafts
///   are not open for applications.
/// * All four statuses are represented.
final List<HousingApplication> kMockApplications = [
  // Outgoing: the current user applying to homes owned by other users.
  HousingApplication(
    id: 'app-1',
    listingId: 'student-room-with-balcony',
    applicantId: 'user-alex',
    requestedMoveIn: DateTime(2026, 9, 1),
    message: 'I work nearby and would love a quiet place to study.',
    status: ApplicationStatus.pending,
    submittedAt: DateTime(2026, 8, 20),
  ),
  HousingApplication(
    id: 'app-2',
    listingId: 'quiet-house-room-pond',
    applicantId: 'user-alex',
    requestedMoveIn: DateTime(2026, 8, 20),
    message: 'Happy to share the kitchen and keep things tidy.',
    status: ApplicationStatus.accepted,
    submittedAt: DateTime(2026, 8, 2),
  ),
  HousingApplication(
    id: 'app-3',
    listingId: 'modern-loft-downtown',
    applicantId: 'user-alex',
    requestedMoveIn: DateTime(2026, 10, 1),
    message: 'Interested in the loft for a longer stay.',
    status: ApplicationStatus.cancelled,
    submittedAt: DateTime(2026, 8, 8),
  ),

  // Incoming: applicants on "Bright room near campus", the current user's
  // published listing.
  HousingApplication(
    id: 'app-4',
    listingId: 'bright-room-near-campus',
    applicantId: 'user-maya',
    requestedMoveIn: DateTime(2026, 9, 15),
    message: 'I am a design student, very tidy, and mostly out on weekdays.',
    status: ApplicationStatus.pending,
    submittedAt: DateTime(2026, 8, 25),
  ),
  HousingApplication(
    id: 'app-5',
    listingId: 'bright-room-near-campus',
    applicantId: 'user-daniel',
    requestedMoveIn: DateTime(2026, 10, 1),
    message: 'Mostly working from home and happy to split utilities.',
    status: ApplicationStatus.pending,
    submittedAt: DateTime(2026, 8, 26),
  ),
  HousingApplication(
    id: 'app-6',
    listingId: 'bright-room-near-campus',
    applicantId: 'user-ava',
    requestedMoveIn: DateTime(2026, 9, 1),
    message: 'Looking for a calm place near the park and bus line.',
    status: ApplicationStatus.rejected,
    submittedAt: DateTime(2026, 8, 12),
  ),
  HousingApplication(
    id: 'app-7',
    listingId: 'bright-room-near-campus',
    applicantId: 'user-sarah',
    requestedMoveIn: DateTime(2026, 9, 20),
    message: 'Withdrew this one last minute.',
    status: ApplicationStatus.cancelled,
    submittedAt: DateTime(2026, 8, 18),
  ),
];