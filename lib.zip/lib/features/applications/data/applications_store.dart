import 'package:flutter/foundation.dart';

import '../../discovery/data/listing.dart';
import '../../discovery/data/listings_store.dart';
import '../../notifications/data/app_notification.dart';
import '../../notifications/data/notifications_store.dart';
import 'housing_application.dart';
import 'mock_applications.dart';
import 'mock_users.dart';

/// Why an application could not be created.
enum ApplicationBlock {
  /// The applicant already has an active application for this listing.
  duplicate,

  /// The listing belongs to the applicant.
  ownListing,

  /// The listing is still a draft, so it is not open for applications.
  unpublished,
}

/// In-memory applications for the current session.
///
/// Mirrors `ListingsStore` and `FavoritesStore`: a plain [ChangeNotifier]
/// singleton shared by My Applications, the owner review screen, and the apply
/// sheet. No package is added and nothing is persisted.
class ApplicationsStore extends ChangeNotifier {
  ApplicationsStore({
    List<HousingApplication>? seed,
    NotificationsStore? notifications,
    ListingsStore? listings,
  })  : _applications = List<HousingApplication>.of(
          seed ?? kMockApplications,
        ),
        _notifications = notifications ?? NotificationsStore.instance,
        _listings = listings ?? ListingsStore.instance;

  static final ApplicationsStore instance = ApplicationsStore();

  final List<HousingApplication> _applications;
  final NotificationsStore _notifications;
  final ListingsStore _listings;

  /// Guards against id collisions when several applications are created
  /// within the same clock tick.
  static int _sequence = 0;

  /// All applications, newest first.
  List<HousingApplication> get all =>
      List<HousingApplication>.unmodifiable(_applications);

  /// Applications submitted by [applicantId].
  List<HousingApplication> forApplicant(String applicantId) =>
      _sorted(_applications.where((HousingApplication a) {
        return a.applicantId == applicantId;
      }));

  /// Applications received for [listingId].
  List<HousingApplication> forListing(String listingId) =>
      _sorted(_applications.where((HousingApplication a) {
        return a.listingId == listingId;
      }));

  /// Returns the applicant's existing application for [listingId] that is
  /// still active, or null when they may apply again.
  HousingApplication? activeApplication({
    required String applicantId,
    required String listingId,
  }) {
    for (final HousingApplication application in _applications) {
      if (application.applicantId != applicantId ||
          application.listingId != listingId) {
        continue;
      }
      if (application.status == ApplicationStatus.pending ||
          application.status == ApplicationStatus.accepted) {
        return application;
      }
    }
    return null;
  }

  /// Checks whether [applicantId] may apply for [listingId].
  ApplicationBlock? blockedReason({
    required String applicantId,
    required String listingId,
    required bool isOwnListing,
    bool isPublished = true,
  }) {
    if (isOwnListing) {
      return ApplicationBlock.ownListing;
    }
    if (!isPublished) {
      return ApplicationBlock.unpublished;
    }
    if (activeApplication(
          applicantId: applicantId,
          listingId: listingId,
        ) !=
        null) {
      return ApplicationBlock.duplicate;
    }
    return null;
  }

  /// Creates a pending application and returns it.
  HousingApplication add({
    required String listingId,
    required String applicantId,
    required DateTime requestedMoveIn,
    required String message,
  }) {
    final HousingApplication application = HousingApplication(
      id: 'app-${DateTime.now().microsecondsSinceEpoch}-${_sequence++}',
      listingId: listingId,
      applicantId: applicantId,
      requestedMoveIn: requestedMoveIn,
      message: message,
      status: ApplicationStatus.pending,
      submittedAt: DateTime.now(),
    );
    _applications.add(application);
    _notifyNewApplication(application);
    notifyListeners();
    return application;
  }

  /// Moves a pending application to [status]. Returns true when changed.
  ///
  /// Decisions are refused once an application is no longer pending so an
  /// owner cannot accept or reject twice.
  bool setStatus(String applicationId, ApplicationStatus status) {
    final int index =
        _applications.indexWhere((HousingApplication a) => a.id == applicationId);
    if (index == -1) {
      return false;
    }
    if (!_applications[index].status.isActionable) {
      return false;
    }
    _applications[index] =
        _applications[index].copyWith(status: status);
    _notifyDecision(_applications[index]);
    notifyListeners();
    return true;
  }

  /// Withdraws a pending application. Returns true when changed.
  bool cancel(String applicationId) {
    return setStatus(applicationId, ApplicationStatus.cancelled);
  }

  /// Drops applications pointing at a deleted listing.
  void removeForListing(String listingId) {
    final int before = _applications.length;
    _applications
        .removeWhere((HousingApplication a) => a.listingId == listingId);
    if (_applications.length != before) {
      notifyListeners();
    }
  }

  /// Notifies the listing owner that a new application arrived.
  void _notifyNewApplication(HousingApplication application) {
    final Listing? listing = _listings.byId(application.listingId);
    if (listing == null) {
      return;
    }
    final String applicantName =
        mockUserById(application.applicantId)?.name ?? 'Someone';

    _notifications.add(
      type: NotificationType.newApplication,
      to: listing.ownerId,
      title: 'New application',
      body: '$applicantName applied for ${listing.title}.',
      actorId: application.applicantId,
      listingId: listing.id,
    );
  }

  /// Notifies the applicant about an accept or reject decision.
  ///
  /// Withdrawals and cancellations generate nothing: there is no notification
  /// type for them in the specification.
  void _notifyDecision(HousingApplication application) {
    final NotificationType? type;
    switch (application.status) {
      case ApplicationStatus.accepted:
        type = NotificationType.applicationAccepted;
      case ApplicationStatus.rejected:
        type = NotificationType.applicationRejected;
      case ApplicationStatus.pending:
      case ApplicationStatus.cancelled:
        return;
    }

    final Listing? listing = _listings.byId(application.listingId);
    if (listing == null) {
      return;
    }

    final String title;
    switch (application.status) {
      case ApplicationStatus.accepted:
        title = 'Application accepted';
      case ApplicationStatus.rejected:
        title = 'Application not accepted';
      case ApplicationStatus.pending:
      case ApplicationStatus.cancelled:
        return;
    }

    _notifications.add(
      type: type,
      to: application.applicantId,
      title: title,
      body: type == NotificationType.applicationAccepted
          ? 'Your application for ${listing.title} was accepted.'
          : 'Your application for ${listing.title} was not accepted.',
      listingId: listing.id,
    );
  }

  /// Newest first: by submission time, then by insertion order for entries
  /// that share a timestamp.
  List<HousingApplication> _sorted(Iterable<HousingApplication> items) {
    final List<HousingApplication> list = items.toList();
    final Map<String, int> positions = <String, int>{
      for (int i = 0; i < _applications.length; i++)
        _applications[i].id: i,
    };
    list.sort((HousingApplication a, HousingApplication b) {
      final int byDate = b.submittedAt.compareTo(a.submittedAt);
      if (byDate != 0) {
        return byDate;
      }
      return (positions[b.id] ?? 0).compareTo(positions[a.id] ?? 0);
    });
    return list;
  }
}