import 'package:flutter/material.dart';

import '../../../../core/resources/app_spacing.dart';
import '../../../discovery/data/listing.dart';
import '../../../../core/domain/entities/listing_entity.dart';
import '../../data/applications_store.dart';
import '../../data/housing_application.dart';
import '../../data/mock_users.dart';

/// Opens the "Apply for housing" sheet.
///
/// Mirrors `ai/design/apply_hosting_bottom_sheet.png`.
Future<void> showApplyForHousingSheet(
  BuildContext context,
  ListingEntity listing,
) {
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    showDragHandle: true,
    builder: (BuildContext sheetContext) =>
        _ApplyForHousingSheet(listing: listing),
  );
}

class _ApplyForHousingSheet extends StatefulWidget {
  const _ApplyForHousingSheet({required this.listing});

  final ListingEntity listing;

  @override
  State<_ApplyForHousingSheet> createState() => _ApplyForHousingSheetState();
}

class _ApplyForHousingSheetState extends State<_ApplyForHousingSheet> {
  final TextEditingController _messageController = TextEditingController();

  DateTime? _moveInDate;
  bool _submitting = false;

  @override
  void dispose() {
    _messageController.dispose();
    super.dispose();
  }

  bool get _isOwnListing => widget.listing.ownerId == CurrentUser.id;

  ApplicationBlock? get _blocked =>
      ApplicationsStore.instance.blockedReason(
        applicantId: CurrentUser.id,
        listingId: widget.listing.id,
        isOwnListing: _isOwnListing,
        isPublished: widget.listing.isPublished,
      );

  Future<void> _pickDate() async {
    final DateTime now = DateTime.now();
    final DateTime today = DateTime(now.year, now.month, now.day);

    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _moveInDate ?? today,
      firstDate: today,
      lastDate: today.add(const Duration(days: 365 * 2)),
      helpText: 'Requested move-in date',
    );

    if (picked != null) {
      setState(() => _moveInDate = picked);
    }
  }

  void _submit() {
    if (_moveInDate == null || _blocked != null || _submitting) {
      return;
    }

    setState(() => _submitting = true);

    final HousingApplication application = ApplicationsStore.instance.add(
      listingId: widget.listing.id,
      applicantId: CurrentUser.id,
      requestedMoveIn: _moveInDate!,
      message: _messageController.text.trim(),
    );

    if (!mounted) {
      return;
    }
    Navigator.of(context).pop();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          'Application sent to ${widget.listing.host.name} · '
          '${application.status.label}',
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final ApplicationBlock? blocked = _blocked;
    final bool canSubmit = _moveInDate != null && blocked == null;

    return SafeArea(
      child: Padding(
        padding: EdgeInsets.only(
          left: AppSpacing.lg,
          right: AppSpacing.lg,
          top: AppSpacing.xs,
          bottom: MediaQuery.viewInsetsOf(context).bottom + AppSpacing.lg,
        ),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Text(
                    'APPLY FOR HOUSING',
                    style: theme.textTheme.labelLarge?.copyWith(
                      color: theme.colorScheme.secondary,
                      letterSpacing: 1.2,
                    ),
                  ),
                  const Spacer(),
                  TextButton(
                    onPressed: () => Navigator.of(context).pop(),
                    child: const Text('Close'),
                  ),
                ],
              ),
              const SizedBox(height: AppSpacing.xs),
              Text(
                'When would you move in?',
                style: theme.textTheme.displayMedium,
              ),
              const SizedBox(height: AppSpacing.lg),
              if (blocked != null) ...[
                _BlockedNotice(block: blocked),
                const SizedBox(height: AppSpacing.lg),
              ] else ...[
                Text(
                  'Requested move-in date',
                  style: theme.textTheme.labelLarge,
                ),
                const SizedBox(height: AppSpacing.xs),
                _DateField(date: _moveInDate, onTap: _pickDate),
                const SizedBox(height: AppSpacing.lg),
                Row(
                  children: [
                    Text('Short message', style: theme.textTheme.labelLarge),
                    const Spacer(),
                    Text('Optional', style: theme.textTheme.bodySmall),
                  ],
                ),
                const SizedBox(height: AppSpacing.xs),
                TextField(
                  controller: _messageController,
                  minLines: 3,
                  maxLines: 4,
                  decoration: const InputDecoration(
                    hintText: 'Introduce yourself to the owner…',
                  ),
                ),
                const SizedBox(height: AppSpacing.lg),
              ],
              SizedBox(
                width: double.infinity,
                child: FilledButton(
                  onPressed: canSubmit ? _submit : null,
                  child: const Text('Submit application'),
                ),
              ),
              const SizedBox(height: AppSpacing.sm),
              Center(
                child: Text(
                  _footerText(blocked),
                  textAlign: TextAlign.center,
                  style: theme.textTheme.bodySmall,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  String _footerText(ApplicationBlock? blocked) {
    switch (blocked) {
      case null:
        return 'Your application will be sent to ${widget.listing.host.name} '
            'with a Pending status.';
      case ApplicationBlock.ownListing:
        return 'This is your own listing.';
      case ApplicationBlock.unpublished:
        return 'This listing is still a draft and is not open yet.';
      case ApplicationBlock.duplicate:
        return 'You already have an active application for this place.';
    }
  }
}

class _DateField extends StatelessWidget {
  const _DateField({required this.date, required this.onTap});

  final DateTime? date;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final String text = date == null
        ? 'mm/dd/yyyy'
        : '${date!.month.toString().padLeft(2, '0')}/'
            '${date!.day.toString().padLeft(2, '0')}/${date!.year}';

    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(AppRadius.md),
      child: InputDecorator(
        decoration: const InputDecoration(
          suffixIcon: Icon(Icons.calendar_today_rounded, size: 18),
        ),
        child: Text(
          text,
          style: date == null
              ? theme.textTheme.bodyMedium?.copyWith(
                  color: theme.textTheme.bodySmall?.color,
                )
              : theme.textTheme.bodyLarge,
        ),
      ),
    );
  }
}

class _BlockedNotice extends StatelessWidget {
  const _BlockedNotice({required this.block});

  final ApplicationBlock block;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(AppSpacing.sm),
      decoration: BoxDecoration(
        color: theme.colorScheme.primaryContainer,
        borderRadius: BorderRadius.circular(AppRadius.md),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(
            Icons.info_outline_rounded,
            size: 18,
            color: theme.colorScheme.secondary,
          ),
          const SizedBox(width: AppSpacing.xs),
          Expanded(
            child: Text(
              block == ApplicationBlock.ownListing
                  ? 'You cannot apply to your own listing.'
                  : block == ApplicationBlock.unpublished
                      ? 'This listing is a draft and is not open for '
                          'applications yet.'
                      : 'You already have an active application for this place.',
              style: theme.textTheme.bodyMedium,
            ),
          ),
        ],
      ),
    );
  }
}