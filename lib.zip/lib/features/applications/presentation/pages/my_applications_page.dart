import 'package:flutter/material.dart';

import '../../../../core/resources/app_spacing.dart';
import '../../../../core/widgets/section_header.dart';
import '../../../discovery/data/listing.dart';
import '../../../discovery/data/listings_store.dart';
import '../../../discovery/presentation/pages/listing_details_page.dart';

import '../../../chat/presentation/pages/chat_page.dart';
import '../../../discovery/presentation/widgets/listing_card_widgets.dart';
import '../../data/applications_store.dart';
import '../../data/housing_application.dart';
import '../../data/mock_users.dart';
import '../widgets/application_card.dart';

/// My Applications.
///
/// Mirrors `ai/design/myApplications_page.png`: "Your applications" heading
/// with subtitle, then a card per application showing the status chip, the
/// listing title, the requested move-in date, and a contextual action.
class MyApplicationsPage extends StatelessWidget {
  const MyApplicationsPage({super.key});

  /// Opens the one-to-one conversation with the listing owner, or the
  /// conversation with the applicant when the current user owns the listing.
  void _openChat(BuildContext context, Listing listing) {
    final String? counterpart = listing.ownerId == CurrentUser.id
        ? _counterpartFor(listing.id)
        : listing.ownerId;

    if (counterpart == null) {
      return;
    }
    final String participantId = counterpart;

    //final conversation =
    //     ChatStore.instance.conversationWith(participantId);
    // ChatStore.instance.markRead(conversation.id);

    // Navigator.of(context).push(
    //   MaterialPageRoute<void>(
    //     builder: (_) => ChatPage(conversation: conversation),
    //   ),
    // );
  }

  /// The applicant whose application should be discussed.
  String? _counterpartFor(String listingId) {
    final List<HousingApplication> received =
        ApplicationsStore.instance.forListing(listingId);
    for (final HousingApplication application in received) {
      if (application.applicantId != CurrentUser.id) {
        return application.applicantId;
      }
    }
    return null;
  }

  Future<void> _confirmCancel(
    BuildContext context,
    HousingApplication application,
  ) async {
    final bool? confirmed = await showDialog<bool>(
      context: context,
      builder: (BuildContext dialogContext) {
        return AlertDialog(
          title: const Text('Cancel this application?'),
          content: const Text(
            'The owner will no longer see this request. You can apply again '
            'later if the space is still open.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(false),
              child: const Text('Keep it'),
            ),
            FilledButton(
              onPressed: () => Navigator.of(dialogContext).pop(true),
              style: FilledButton.styleFrom(
                backgroundColor: Theme.of(dialogContext).colorScheme.error,
              ),
              child: const Text('Cancel application'),
            ),
          ],
        );
      },
    );

    if (confirmed ?? false) {
      ApplicationsStore.instance.cancel(application.id);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded),
          tooltip: 'Back',
          onPressed: () => Navigator.of(context).pop(),
        ),
      ),
      body: SafeArea(
        child: ListenableBuilder(
          listenable: Listenable.merge([
            ApplicationsStore.instance,
            ListingsStore.instance,
          ]),
          builder: (BuildContext context, Widget? child) {
            final List<HousingApplication> applications =
                ApplicationsStore.instance
                    .forApplicant(CurrentUser.id);

            return CustomScrollView(
              slivers: [
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(
                      AppSpacing.pageHorizontal,
                      AppSpacing.md,
                      AppSpacing.pageHorizontal,
                      AppSpacing.md,
                    ),
                    child: const SectionHeader(
                      title: 'Your applications',
                      subtitle:
                          'Track your housing requests in one place.',
                    ),
                  ),
                ),
                if (applications.isEmpty)
                  const SliverFillRemaining(
                    hasScrollBody: false,
                    child: EmptyResults(
                      title: 'No applications yet',
                      message:
                          'Apply to a place you like and it will show up here.',
                    ),
                  )
                else
                  SliverList.separated(
                    itemCount: applications.length,
                    separatorBuilder: (_, _) =>
                        const SizedBox(height: AppSpacing.sm),
                    itemBuilder: (BuildContext context, int index) {
                      final HousingApplication application =
                          applications[index];
                      final Listing? listing =
                          ListingsStore.instance.byId(application.listingId);

                      if (listing == null) {
                        return const SizedBox.shrink();
                      }

                      return Padding(
                        padding: const EdgeInsets.symmetric(
                          horizontal: AppSpacing.pageHorizontal,
                        ),
                        child: ApplicationCard(
                          application: application,
                          listing: listing,
                          subtitle:
                              'Move-in: ${formatMoveInDate(application.requestedMoveIn)}',
                          // onTap: () => Navigator.of(context).push(
                          //   MaterialPageRoute<void>(
                          //     builder: (_) =>
                          //         ListingDetailsPage(listing: listing),
                          //   ),
                          // ),
                          actions: [
                            ApplicationActionButton(
                              label: 'Open listing',
                              onTap: () {}
                              //  Navigator.of(context).push(
                              //   MaterialPageRoute<void>(
                              //     builder: (_) =>
                              //         ListingDetailsPage(listing: listing),
                              //   ),
                              // ),
                            ),
                            if (application.status.isCancellable)
                              ApplicationActionButton(
                                label: 'Cancel',
                                onTap: () =>
                                    _confirmCancel(context, application),
                              )
                            else if (application.status ==
                                ApplicationStatus.accepted)
                              ApplicationActionButton(
                                label: 'Chat',
                                icon: Icons.chat_bubble_outline_rounded,
                                onTap: () => _openChat(context, listing),
                              ),
                          ],
                        ),
                      );
                    },
                  ),
              ],
            );
          },
        ),
      ),
    );
  }
}