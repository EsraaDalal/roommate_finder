import 'package:flutter/material.dart';

import '../../../../core/resources/app_spacing.dart';
import '../../../applications/data/mock_users.dart';
import '../../../applications/presentation/pages/my_applications_page.dart';
import '../../../applications/presentation/pages/received_applications_page.dart';

import '../../../chat/presentation/pages/chat_page.dart';
import '../../../discovery/data/listing.dart';
import '../../../discovery/data/listings_store.dart';
import '../../../discovery/presentation/widgets/listing_card_widgets.dart';
import '../../data/app_notification.dart';
import '../../data/notifications_store.dart';

/// Notifications.
///
/// Mirrors `ai/design/notifiaction_page .png`: a "Mark read" action in the app
/// bar and one row per notification with a tinted icon tile, title, body, and a
/// relative timestamp.
///
/// Tapping a row opens the related conversation or listing.
class NotificationsPage extends StatelessWidget {
  const NotificationsPage({super.key});

  void _open(BuildContext context, AppNotification notification) {
    // A conversation notification opens the thread directly.
    if (notification.type == NotificationType.newMessage &&
        notification.conversationId != null) {
      // final conversation =
      //     ChatStore.instance.byId(notification.conversationId!);
      // if (conversation != null) {
      //   ChatStore.instance.markRead(conversation.id);
      //   // Navigator.of(context).push(
      //   //   MaterialPageRoute<void>(
      //   //     builder: (_) => ChatPage(conversation: conversation),
      //   //   ),
      //   // );
      //   return;
      // }
    }

    if (notification.listingId != null) {
      final Listing? listing =
          ListingsStore.instance.byId(notification.listingId!);
      if (listing != null) {
        // Owner-side notices open the received applications review screen;
        // applicant notices open My Applications.
        final bool isOwner = listing.ownerId == CurrentUser.id;
        Navigator.of(context).push(
          MaterialPageRoute<void>(
            builder: (_) => isOwner
                ? ReceivedApplicationsPage(listing: listing)
                : const MyApplicationsPage(),
          ),
        );
        return;
      }
    }

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(notification.title)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded),
          tooltip: 'Back',
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: const Text('Notifications'),
        actions: [
          TextButton(
            onPressed: () => NotificationsStore.instance.markAllRead(),
            child: const Text('Mark read'),
          ),
        ],
      ),
      body: SafeArea(
        child: ListenableBuilder(
          listenable: Listenable.merge([
            NotificationsStore.instance,
            ListingsStore.instance,
          ]),
          builder: (BuildContext context, Widget? child) {
            final List<AppNotification> notifications =
                NotificationsStore.instance.all;

            if (notifications.isEmpty) {
              return const EmptyResults(
                title: 'No notifications yet',
                message: 'Activity on your homes will show up here.',
              );
            }

            return ListView.separated(
              padding: const EdgeInsets.symmetric(vertical: AppSpacing.xs),
              itemCount: notifications.length,
              separatorBuilder: (_, _) =>
                  const Divider(height: 1, indent: 64),
              itemBuilder: (BuildContext context, int index) {
                final AppNotification notification = notifications[index];
                return _NotificationTile(
                  notification: notification,
                  onTap: () => _open(context, notification),
                );
              },
            );
          },
        ),
      ),
    );
  }
}

class _NotificationTile extends StatelessWidget {
  const _NotificationTile({required this.notification, required this.onTap});

  final AppNotification notification;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);

    return Material(
      color: theme.colorScheme.surface,
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(
            horizontal: AppSpacing.md,
            vertical: AppSpacing.sm,
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: theme.colorScheme.primaryContainer,
                  borderRadius: BorderRadius.circular(AppRadius.sm),
                ),
                child: Icon(
                  _iconFor(notification.type),
                  size: 20,
                  color: theme.colorScheme.secondary,
                ),
              ),
              const SizedBox(width: AppSpacing.sm),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(notification.title, style: theme.textTheme.titleMedium),
                    const SizedBox(height: 2),
                    Text(notification.body, style: theme.textTheme.bodySmall),
                  ],
                ),
              ),
              const SizedBox(width: AppSpacing.xs),
              Text(
                formatNotificationTimestamp(notification.createdAt),
                style: theme.textTheme.bodySmall?.copyWith(fontSize: 11),
              ),
            ],
          ),
        ),
      ),
    );
  }

  IconData _iconFor(NotificationType type) {
    switch (type) {
      case NotificationType.newApplication:
        return Icons.calendar_today_rounded;
      case NotificationType.applicationAccepted:
        return Icons.check_rounded;
      case NotificationType.applicationRejected:
        return Icons.close_rounded;
      case NotificationType.newMessage:
        return Icons.chat_bubble_rounded;
    }
  }
}
