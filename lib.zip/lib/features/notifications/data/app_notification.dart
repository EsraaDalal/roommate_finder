import 'package:flutter/foundation.dart';

/// The four notification types supported by the specification.
enum NotificationType {
  newApplication,
  applicationAccepted,
  applicationRejected,
  newMessage,
}

/// An in-app notification for the current user.
@immutable
class AppNotification {
  const AppNotification({
    required this.id,
    required this.type,
    required this.recipientId,
    required this.title,
    required this.body,
    required this.createdAt,
    this.actorId,
    this.listingId,
    this.conversationId,
    this.isRead = false,
  });

  final String id;
  final NotificationType type;
  final String recipientId;
  final String title;
  final String body;
  final DateTime createdAt;

  /// Who triggered the notification, when there is one.
  final String? actorId;
  final String? listingId;
  final String? conversationId;
  final bool isRead;

  AppNotification copyWith({bool? isRead}) {
    return AppNotification(
      id: id,
      type: type,
      recipientId: recipientId,
      title: title,
      body: body,
      createdAt: createdAt,
      actorId: actorId,
      listingId: listingId,
      conversationId: conversationId,
      isRead: isRead ?? this.isRead,
    );
  }
}

/// Formats a notification timestamp the way the design shows it: "5m", "2h",
/// "Yesterday".
String formatNotificationTimestamp(DateTime time) {
  final DateTime now = DateTime.now();
  final Duration difference = now.difference(time);

  if (difference.inMinutes < 1) {
    return 'now';
  }
  if (difference.inHours < 1) {
    return '${difference.inMinutes}m';
  }
  if (difference.inHours < 24) {
    return '${difference.inHours}h';
  }
  if (difference.inDays == 1) {
    return 'Yesterday';
  }
  return '${difference.inDays}d';
}