import 'app_notification.dart';

/// Seed notifications for the current user so every supported type is visible
/// on first run.
final List<AppNotification> kMockNotifications = [
  AppNotification(
    id: 'notif-1',
    type: NotificationType.newApplication,
    recipientId: 'user-alex',
    title: 'New application',
    body: 'Maya applied for Bright room near campus.',
    createdAt: DateTime.now().subtract(const Duration(minutes: 5)),
    actorId: 'user-maya',
    listingId: 'bright-room-near-campus',
  ),
  AppNotification(
    id: 'notif-2',
    type: NotificationType.applicationAccepted,
    recipientId: 'user-alex',
    title: 'Application accepted',
    body:
        'Your application for Quiet house room by the pond was accepted.',
    createdAt: DateTime.now().subtract(const Duration(hours: 2)),
    actorId: 'user-sarah',
    listingId: 'quiet-house-room-pond',
  ),
  AppNotification(
    id: 'notif-3',
    type: NotificationType.applicationRejected,
    recipientId: 'user-alex',
    title: 'Application not accepted',
    body: 'Your application for Modern loft downtown was not accepted.',
    createdAt: DateTime.now().subtract(const Duration(hours: 3)),
    actorId: 'user-sarah',
    listingId: 'modern-loft-downtown',
  ),
  AppNotification(
    id: 'notif-4',
    type: NotificationType.newMessage,
    recipientId: 'user-alex',
    title: 'New message',
    body: 'Sarah: Saturday afternoon works perfectly.',
    createdAt: DateTime.now().subtract(const Duration(days: 1)),
    actorId: 'user-sarah',
    conversationId: 'conv-sarah',
  ),
];