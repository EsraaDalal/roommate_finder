import 'package:flutter/foundation.dart';

import 'app_notification.dart';
import 'mock_notifications.dart';

/// In-memory notifications for the current session.
///
/// Follows the same lightweight pattern as `ListingsStore`,
/// `FavoritesStore`, and `ApplicationsStore`: a [ChangeNotifier] with no
/// package, no persistence, and no Firebase. Notifications are only created by
/// real state-changing actions, never by building a widget.
class NotificationsStore extends ChangeNotifier {
  NotificationsStore({
    List<AppNotification>? seed,
    this.recipientId = 'user-alex',
  }) : _notifications = List<AppNotification>.of(
          seed ?? kMockNotifications,
        );

  static final NotificationsStore instance = NotificationsStore();

  final List<AppNotification> _notifications;

  /// The signed-in user. Notifications addressed to anyone else are stored but
  /// never surfaced.
  final String recipientId;

  /// Notifications for the current user, newest first.
  List<AppNotification> get all {
    final List<AppNotification> mine = _notifications
        .where((AppNotification n) => n.recipientId == recipientId)
        .toList();
    mine.sort(
      (AppNotification a, AppNotification b) =>
          b.createdAt.compareTo(a.createdAt),
    );
    return mine;
  }

  int get unreadCount =>
      all.where((AppNotification n) => !n.isRead).length;

  /// Every stored notification, including those addressed to other users.
  /// Used to verify that actions notify the correct recipient.
  List<AppNotification> get allStored =>
      List<AppNotification>.unmodifiable(_notifications);

  /// Adds a notification addressed to [to].
  ///
  /// Returns null when [to] is the current user, since they are being notified
  /// about their own action.
  AppNotification? add({
    required NotificationType type,
    required String to,
    required String title,
    required String body,
    String? actorId,
    String? listingId,
    String? conversationId,
  }) {
    // Never notify someone about their own action.
    if (to == recipientId) {
      return null;
    }

    final AppNotification notification = AppNotification(
      id: 'notif-${DateTime.now().microsecondsSinceEpoch}-${_sequence++}',
      type: type,
      recipientId: to,
      title: title,
      body: body,
      createdAt: DateTime.now(),
      actorId: actorId,
      listingId: listingId,
      conversationId: conversationId,
    );
    _notifications.add(notification);
    notifyListeners();
    return notification;
  }

  void markAllRead() {
    bool changed = false;
    for (int i = 0; i < _notifications.length; i++) {
      if (_notifications[i].recipientId == recipientId &&
          !_notifications[i].isRead) {
        _notifications[i] = _notifications[i].copyWith(isRead: true);
        changed = true;
      }
    }
    if (changed) {
      notifyListeners();
    }
  }

  /// Removes notifications tied to a deleted listing.
  void removeForListing(String listingId) {
    final int before = _notifications.length;
    _notifications
        .removeWhere((AppNotification n) => n.listingId == listingId);
    if (_notifications.length != before) {
      notifyListeners();
    }
  }

  /// Guards against id collisions within the same clock tick.
  static int _sequence = 0;
}